# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/AvatarInputHandler/commands/input_handler_command.py
from svarog_script.py_component import Component

class InputHandlerCommand(Component):

    def handleKeyEvent(self, isDown, key, mods, event=None):
        pass
