# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/miniclient/lobby/strongholds/__init__.py
import pointcuts as _pointcuts

def configure_pointcuts():
    _pointcuts.MakeStrongholdsUnavailable()
