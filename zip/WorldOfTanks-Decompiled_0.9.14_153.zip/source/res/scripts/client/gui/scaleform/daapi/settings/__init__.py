# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/Scaleform/daapi/settings/__init__.py


class BUTTON_LINKAGES(object):
    BUTTON_BLACK = 'ButtonBlack'
    BUTTON_RED = 'ButtonRed'
    BUTTON_NORMAL = 'ButtonNormal'
