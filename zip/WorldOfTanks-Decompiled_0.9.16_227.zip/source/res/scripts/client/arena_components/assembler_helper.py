# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/arena_components/assembler_helper.py
from constants import ARENA_BONUS_TYPE, ARENA_BONUS_TYPE_CAPS
COMPONENT_ASSEMBLER = {}
ARENA_BONUS_TYPE_CAP_COMPONENTS = {}
