# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/customization/__init__.py
from gui.customization.controller import g_customizationController
__all__ = ('g_customizationController',)
