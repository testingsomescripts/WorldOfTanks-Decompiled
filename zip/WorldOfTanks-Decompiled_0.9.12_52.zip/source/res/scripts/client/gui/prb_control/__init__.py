# Embedded file name: scripts/client/gui/prb_control/__init__.py
pass
