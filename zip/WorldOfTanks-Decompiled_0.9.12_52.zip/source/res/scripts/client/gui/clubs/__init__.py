# Embedded file name: scripts/client/gui/clubs/__init__.py
pass
