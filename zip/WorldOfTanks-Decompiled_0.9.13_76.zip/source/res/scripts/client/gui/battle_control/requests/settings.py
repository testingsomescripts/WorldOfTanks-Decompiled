# Python 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/battle_control/requests/settings.py
from shared_utils import CONST_CONTAINER
DEFAULT_COOLDOWN = 1.0

class AVATAR_REQUEST_TYPE(CONST_CONTAINER):
    SEND_INVITES = 1
