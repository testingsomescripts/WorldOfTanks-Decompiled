# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/Scaleform/daapi/view/battle/classic/frag_correlation_bar.py
from gui.Scaleform.daapi.view.meta.FragCorrelationBarMeta import FragCorrelationBarMeta

class FragCorrelationBar(FragCorrelationBarMeta):

    def __init__(self):
        super(FragCorrelationBar, self).__init__()

    def _populate(self):
        super(FragCorrelationBar, self)._populate()

    def _dispose(self):
        super(FragCorrelationBar, self)._dispose()
